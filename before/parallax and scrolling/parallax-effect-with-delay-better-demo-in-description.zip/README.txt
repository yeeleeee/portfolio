A Pen created at CodePen.io. You can find this one at https://codepen.io/Sahil89/pen/wrVEOj.

 I noticed that my this demo is being viewed/used by a lot of people. Recently I created this following demo that works a lot more efficiently, so check it out. https://codepen.io/Sahil89/pen/PRKQVp